import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../cubits/auth_cubit.dart';
import '../services/api_service.dart';
import '../widgets/store_analytics_tab.dart';
import 'login_screen.dart';

// ========== علامة التبويب الرئيسية ==========
class AccountantHomeTab extends StatelessWidget {
  final ApiService api;
  const AccountantHomeTab({super.key, required this.api});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: Future.wait([
        api.getAdminStats(),
        api.getCustomersWithBalance(),
        api.getDriversBalances(),
        api.getStoresBalances(),
      ]),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text('خطأ: ${snapshot.error}'));
        }
        final stats = snapshot.data![0] as Map<String, dynamic>;
        final customersBalance = snapshot.data![1] as List;
        final driversBalance = snapshot.data![2] as List;
        final storesBalance = snapshot.data![3] as List;

        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildStatCard('إجمالي الطلبات اليوم', stats['total_orders_today'] ?? 0),
            _buildStatCard('إجمالي الإيرادات اليوم', stats['total_delivery_fee_today'] ?? 0),
            _buildStatCard('الطلبات المعلقة', stats['pending_orders'] ?? 0),
            const Divider(height: 32),
            _buildBalanceList('أرصدة الزبائن', customersBalance, 'name', 'balance'),
            _buildBalanceList('أرصدة السائقين', driversBalance, 'name', 'commission_balance'),
            _buildBalanceList('أرصدة المتاجر', storesBalance, 'name', 'balance'),
          ],
        );
      },
    );
  }

  Widget _buildStatCard(String title, dynamic value) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        trailing: Text(value.toString(), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget _buildBalanceList(String title, List items, String nameKey, String balanceKey) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ...items.map((item) => ListTile(
          title: Text(item[nameKey]?.toString() ?? ''),
          trailing: Text('${item[balanceKey]} ل.س'),
        )),
      ],
    );
  }
}

// ========== علامة تبويب المعاملات ==========
class TransactionsTab extends StatelessWidget {
  final ApiService api;
  const TransactionsTab({super.key, required this.api});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: api.get('transactions'),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text('خطأ: ${snapshot.error}'));
        }
        final List data = snapshot.data is List ? snapshot.data : (snapshot.data['data'] as List);
        return ListView.builder(
          itemCount: data.length,
          itemBuilder: (context, index) {
            final txn = data[index];
            return Card(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: ListTile(
                title: Text(txn['type']),
                subtitle: Text(txn['notes'] ?? ''),
                trailing: Text('${txn['amount']} ل.س'),
              ),
            );
          },
        );
      },
    );
  }
}

// ========== علامة تبويب التقارير ==========
class ReportsTab extends StatelessWidget {
  final ApiService api;
  const ReportsTab({super.key, required this.api});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: api.get('reports/profits'),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text('خطأ: ${snapshot.error}'));
        }
        final List data = snapshot.data['data'] as List;
        return ListView.builder(
          itemCount: data.length,
          itemBuilder: (context, index) {
            final item = data[index];
            return Card(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: ListTile(
                title: Text('التاريخ: ${item['date']}'),
                subtitle: Text('عدد الطلبات: ${item['orders_count']}'),
                trailing: Text('${item['total_fees']} ل.س'),
              ),
            );
          },
        );
      },
    );
  }
}

// ========== لوحة تحكم المحاسب الرئيسية ==========
class AccountantDashboard extends StatefulWidget {
  const AccountantDashboard({super.key});

  @override
  State<AccountantDashboard> createState() => _AccountantDashboardState();
}

class _AccountantDashboardState extends State<AccountantDashboard> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final ApiService _api = ApiService();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _logout() async {
    await context.read<AuthCubit>().logout();
    if (mounted) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('لوحة تحكم المحاسب'),
          backgroundColor: const Color(0xFF54d4dd),
          bottom: TabBar(
            controller: _tabController,
            tabs: const [
              Tab(text: 'الرئيسية', icon: Icon(Icons.dashboard)),
              Tab(text: 'المعاملات', icon: Icon(Icons.history)),
              Tab(text: 'التقارير', icon: Icon(Icons.bar_chart)),
              Tab(text: 'تحليلات المتاجر', icon: Icon(Icons.store)),
            ],
          ),
          actions: [
            IconButton(onPressed: _logout, icon: const Icon(Icons.logout), tooltip: 'تسجيل خروج'),
          ],
        ),
        body: TabBarView(
          controller: _tabController,
          children: [
            AccountantHomeTab(api: _api),
            TransactionsTab(api: _api),
            ReportsTab(api: _api),
            StoreAnalyticsTab(api: _api),
          ],
        ),
      ),
    );
  }
}